/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "solicitud_detallado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SolicitudDetallado.findAll", query = "SELECT s FROM SolicitudDetallado s")
    , @NamedQuery(name = "SolicitudDetallado.findByDniClientes", query = "SELECT s FROM SolicitudDetallado s WHERE s.solicitudDetalladoPK.dniClientes = :dniClientes")
    , @NamedQuery(name = "SolicitudDetallado.findByIdServicios", query = "SELECT s FROM SolicitudDetallado s WHERE s.solicitudDetalladoPK.idServicios = :idServicios")
    , @NamedQuery(name = "SolicitudDetallado.findByCondicionVehiculo", query = "SELECT s FROM SolicitudDetallado s WHERE s.condicionVehiculo = :condicionVehiculo")})
public class SolicitudDetallado implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SolicitudDetalladoPK solicitudDetalladoPK;
    @Basic(optional = false)
    @Column(name = "condicion_vehiculo")
    private String condicionVehiculo;
    @JoinColumn(name = "dni_clientes", referencedColumnName = "dni", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Clientes clientes;
    @JoinColumn(name = "id_servicios", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Servicios servicios;

    public SolicitudDetallado() {
    }

    public SolicitudDetallado(SolicitudDetalladoPK solicitudDetalladoPK) {
        this.solicitudDetalladoPK = solicitudDetalladoPK;
    }

    public SolicitudDetallado(SolicitudDetalladoPK solicitudDetalladoPK, String condicionVehiculo) {
        this.solicitudDetalladoPK = solicitudDetalladoPK;
        this.condicionVehiculo = condicionVehiculo;
    }

    public SolicitudDetallado(int dniClientes, int idServicios) {
        this.solicitudDetalladoPK = new SolicitudDetalladoPK(dniClientes, idServicios);
    }

    public SolicitudDetalladoPK getSolicitudDetalladoPK() {
        return solicitudDetalladoPK;
    }

    public void setSolicitudDetalladoPK(SolicitudDetalladoPK solicitudDetalladoPK) {
        this.solicitudDetalladoPK = solicitudDetalladoPK;
    }

    public String getCondicionVehiculo() {
        return condicionVehiculo;
    }

    public void setCondicionVehiculo(String condicionVehiculo) {
        this.condicionVehiculo = condicionVehiculo;
    }

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    public Servicios getServicios() {
        return servicios;
    }

    public void setServicios(Servicios servicios) {
        this.servicios = servicios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (solicitudDetalladoPK != null ? solicitudDetalladoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SolicitudDetallado)) {
            return false;
        }
        SolicitudDetallado other = (SolicitudDetallado) object;
        if ((this.solicitudDetalladoPK == null && other.solicitudDetalladoPK != null) || (this.solicitudDetalladoPK != null && !this.solicitudDetalladoPK.equals(other.solicitudDetalladoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.SolicitudDetallado[ solicitudDetalladoPK=" + solicitudDetalladoPK + " ]";
    }
    
}
