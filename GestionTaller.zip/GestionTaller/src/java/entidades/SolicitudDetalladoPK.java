/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author user
 */
@Embeddable
public class SolicitudDetalladoPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "dni_clientes")
    private int dniClientes;
    @Basic(optional = false)
    @Column(name = "id_servicios")
    private int idServicios;

    public SolicitudDetalladoPK() {
    }

    public SolicitudDetalladoPK(int dniClientes, int idServicios) {
        this.dniClientes = dniClientes;
        this.idServicios = idServicios;
    }

    public int getDniClientes() {
        return dniClientes;
    }

    public void setDniClientes(int dniClientes) {
        this.dniClientes = dniClientes;
    }

    public int getIdServicios() {
        return idServicios;
    }

    public void setIdServicios(int idServicios) {
        this.idServicios = idServicios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) dniClientes;
        hash += (int) idServicios;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SolicitudDetalladoPK)) {
            return false;
        }
        SolicitudDetalladoPK other = (SolicitudDetalladoPK) object;
        if (this.dniClientes != other.dniClientes) {
            return false;
        }
        if (this.idServicios != other.idServicios) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.SolicitudDetalladoPK[ dniClientes=" + dniClientes + ", idServicios=" + idServicios + " ]";
    }
    
}
