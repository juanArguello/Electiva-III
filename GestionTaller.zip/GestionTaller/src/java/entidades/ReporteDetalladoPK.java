/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author user
 */
@Embeddable
public class ReporteDetalladoPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "id_servicios")
    private int idServicios;
    @Basic(optional = false)
    @Column(name = "id_mecanico")
    private int idMecanico;

    public ReporteDetalladoPK() {
    }

    public ReporteDetalladoPK(int idServicios, int idMecanico) {
        this.idServicios = idServicios;
        this.idMecanico = idMecanico;
    }

    public int getIdServicios() {
        return idServicios;
    }

    public void setIdServicios(int idServicios) {
        this.idServicios = idServicios;
    }

    public int getIdMecanico() {
        return idMecanico;
    }

    public void setIdMecanico(int idMecanico) {
        this.idMecanico = idMecanico;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idServicios;
        hash += (int) idMecanico;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReporteDetalladoPK)) {
            return false;
        }
        ReporteDetalladoPK other = (ReporteDetalladoPK) object;
        if (this.idServicios != other.idServicios) {
            return false;
        }
        if (this.idMecanico != other.idMecanico) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.ReporteDetalladoPK[ idServicios=" + idServicios + ", idMecanico=" + idMecanico + " ]";
    }
    
}
