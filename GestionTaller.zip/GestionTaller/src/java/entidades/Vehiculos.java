/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "vehiculos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Vehiculos.findAll", query = "SELECT v FROM Vehiculos v")
    , @NamedQuery(name = "Vehiculos.findByMatricula", query = "SELECT v FROM Vehiculos v WHERE v.matricula = :matricula")
    , @NamedQuery(name = "Vehiculos.findByModelo", query = "SELECT v FROM Vehiculos v WHERE v.modelo = :modelo")
    , @NamedQuery(name = "Vehiculos.findByColor", query = "SELECT v FROM Vehiculos v WHERE v.color = :color")
    , @NamedQuery(name = "Vehiculos.findByFechaEntrada", query = "SELECT v FROM Vehiculos v WHERE v.fechaEntrada = :fechaEntrada")
    , @NamedQuery(name = "Vehiculos.findByHoraTaller", query = "SELECT v FROM Vehiculos v WHERE v.horaTaller = :horaTaller")})
public class Vehiculos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "matricula")
    private String matricula;
    @Basic(optional = false)
    @Column(name = "modelo")
    private String modelo;
    @Basic(optional = false)
    @Column(name = "color")
    private String color;
    @Basic(optional = false)
    @Column(name = "fecha_entrada")
    @Temporal(TemporalType.DATE)
    private Date fechaEntrada;
    @Basic(optional = false)
    @Column(name = "hora_taller")
    private int horaTaller;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vehiculos")
    private Collection<ReparacionDetallado> reparacionDetalladoCollection;
    @JoinColumn(name = "dni_clientes", referencedColumnName = "dni")
    @ManyToOne
    private Clientes dniClientes;

    public Vehiculos() {
    }

    public Vehiculos(String matricula) {
        this.matricula = matricula;
    }

    public Vehiculos(String matricula, String modelo, String color, Date fechaEntrada, int horaTaller) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.color = color;
        this.fechaEntrada = fechaEntrada;
        this.horaTaller = horaTaller;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public int getHoraTaller() {
        return horaTaller;
    }

    public void setHoraTaller(int horaTaller) {
        this.horaTaller = horaTaller;
    }

    @XmlTransient
    public Collection<ReparacionDetallado> getReparacionDetalladoCollection() {
        return reparacionDetalladoCollection;
    }

    public void setReparacionDetalladoCollection(Collection<ReparacionDetallado> reparacionDetalladoCollection) {
        this.reparacionDetalladoCollection = reparacionDetalladoCollection;
    }

    public Clientes getDniClientes() {
        return dniClientes;
    }

    public void setDniClientes(Clientes dniClientes) {
        this.dniClientes = dniClientes;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (matricula != null ? matricula.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vehiculos)) {
            return false;
        }
        Vehiculos other = (Vehiculos) object;
        if ((this.matricula == null && other.matricula != null) || (this.matricula != null && !this.matricula.equals(other.matricula))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Vehiculos[ matricula=" + matricula + " ]";
    }
    
}
