/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "reporte_detallado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ReporteDetallado.findAll", query = "SELECT r FROM ReporteDetallado r")
    , @NamedQuery(name = "ReporteDetallado.findByIdServicios", query = "SELECT r FROM ReporteDetallado r WHERE r.reporteDetalladoPK.idServicios = :idServicios")
    , @NamedQuery(name = "ReporteDetallado.findByIdMecanico", query = "SELECT r FROM ReporteDetallado r WHERE r.reporteDetalladoPK.idMecanico = :idMecanico")
    , @NamedQuery(name = "ReporteDetallado.findByPrecioManoObra", query = "SELECT r FROM ReporteDetallado r WHERE r.precioManoObra = :precioManoObra")})
public class ReporteDetallado implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReporteDetalladoPK reporteDetalladoPK;
    @Basic(optional = false)
    @Column(name = "precio_mano_obra")
    private int precioManoObra;
    @JoinColumn(name = "id_mecanico", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Mecanico mecanico;
    @JoinColumn(name = "id_servicios", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Servicios servicios;

    public ReporteDetallado() {
    }

    public ReporteDetallado(ReporteDetalladoPK reporteDetalladoPK) {
        this.reporteDetalladoPK = reporteDetalladoPK;
    }

    public ReporteDetallado(ReporteDetalladoPK reporteDetalladoPK, int precioManoObra) {
        this.reporteDetalladoPK = reporteDetalladoPK;
        this.precioManoObra = precioManoObra;
    }

    public ReporteDetallado(int idServicios, int idMecanico) {
        this.reporteDetalladoPK = new ReporteDetalladoPK(idServicios, idMecanico);
    }

    public ReporteDetalladoPK getReporteDetalladoPK() {
        return reporteDetalladoPK;
    }

    public void setReporteDetalladoPK(ReporteDetalladoPK reporteDetalladoPK) {
        this.reporteDetalladoPK = reporteDetalladoPK;
    }

    public int getPrecioManoObra() {
        return precioManoObra;
    }

    public void setPrecioManoObra(int precioManoObra) {
        this.precioManoObra = precioManoObra;
    }

    public Mecanico getMecanico() {
        return mecanico;
    }

    public void setMecanico(Mecanico mecanico) {
        this.mecanico = mecanico;
    }

    public Servicios getServicios() {
        return servicios;
    }

    public void setServicios(Servicios servicios) {
        this.servicios = servicios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reporteDetalladoPK != null ? reporteDetalladoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReporteDetallado)) {
            return false;
        }
        ReporteDetallado other = (ReporteDetallado) object;
        if ((this.reporteDetalladoPK == null && other.reporteDetalladoPK != null) || (this.reporteDetalladoPK != null && !this.reporteDetalladoPK.equals(other.reporteDetalladoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.ReporteDetallado[ reporteDetalladoPK=" + reporteDetalladoPK + " ]";
    }
    
}
