/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author user
 */
@Embeddable
public class ReparacionDetalladoPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "matricula_vehiculos")
    private String matriculaVehiculos;
    @Basic(optional = false)
    @Column(name = "id_servicios")
    private int idServicios;

    public ReparacionDetalladoPK() {
    }

    public ReparacionDetalladoPK(String matriculaVehiculos, int idServicios) {
        this.matriculaVehiculos = matriculaVehiculos;
        this.idServicios = idServicios;
    }

    public String getMatriculaVehiculos() {
        return matriculaVehiculos;
    }

    public void setMatriculaVehiculos(String matriculaVehiculos) {
        this.matriculaVehiculos = matriculaVehiculos;
    }

    public int getIdServicios() {
        return idServicios;
    }

    public void setIdServicios(int idServicios) {
        this.idServicios = idServicios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (matriculaVehiculos != null ? matriculaVehiculos.hashCode() : 0);
        hash += (int) idServicios;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReparacionDetalladoPK)) {
            return false;
        }
        ReparacionDetalladoPK other = (ReparacionDetalladoPK) object;
        if ((this.matriculaVehiculos == null && other.matriculaVehiculos != null) || (this.matriculaVehiculos != null && !this.matriculaVehiculos.equals(other.matriculaVehiculos))) {
            return false;
        }
        if (this.idServicios != other.idServicios) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.ReparacionDetalladoPK[ matriculaVehiculos=" + matriculaVehiculos + ", idServicios=" + idServicios + " ]";
    }
    
}
