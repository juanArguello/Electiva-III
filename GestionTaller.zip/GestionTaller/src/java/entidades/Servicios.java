/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "servicios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Servicios.findAll", query = "SELECT s FROM Servicios s")
    , @NamedQuery(name = "Servicios.findById", query = "SELECT s FROM Servicios s WHERE s.id = :id")
    , @NamedQuery(name = "Servicios.findByNombre", query = "SELECT s FROM Servicios s WHERE s.nombre = :nombre")
    , @NamedQuery(name = "Servicios.findByTipoServico", query = "SELECT s FROM Servicios s WHERE s.tipoServico = :tipoServico")})
public class Servicios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "tipo_servico")
    private String tipoServico;
    @JoinColumn(name = "id_respuestos", referencedColumnName = "id")
    @ManyToOne
    private Respuestos idRespuestos;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "servicios")
    private Collection<SolicitudDetallado> solicitudDetalladoCollection;
    @OneToMany(mappedBy = "idServicios")
    private Collection<Respuestos> respuestosCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "servicios")
    private Collection<ReparacionDetallado> reparacionDetalladoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "servicios")
    private Collection<ReporteDetallado> reporteDetalladoCollection;

    public Servicios() {
    }

    public Servicios(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(String tipoServico) {
        this.tipoServico = tipoServico;
    }

    public Respuestos getIdRespuestos() {
        return idRespuestos;
    }

    public void setIdRespuestos(Respuestos idRespuestos) {
        this.idRespuestos = idRespuestos;
    }

    @XmlTransient
    public Collection<SolicitudDetallado> getSolicitudDetalladoCollection() {
        return solicitudDetalladoCollection;
    }

    public void setSolicitudDetalladoCollection(Collection<SolicitudDetallado> solicitudDetalladoCollection) {
        this.solicitudDetalladoCollection = solicitudDetalladoCollection;
    }

    @XmlTransient
    public Collection<Respuestos> getRespuestosCollection() {
        return respuestosCollection;
    }

    public void setRespuestosCollection(Collection<Respuestos> respuestosCollection) {
        this.respuestosCollection = respuestosCollection;
    }

    @XmlTransient
    public Collection<ReparacionDetallado> getReparacionDetalladoCollection() {
        return reparacionDetalladoCollection;
    }

    public void setReparacionDetalladoCollection(Collection<ReparacionDetallado> reparacionDetalladoCollection) {
        this.reparacionDetalladoCollection = reparacionDetalladoCollection;
    }

    @XmlTransient
    public Collection<ReporteDetallado> getReporteDetalladoCollection() {
        return reporteDetalladoCollection;
    }

    public void setReporteDetalladoCollection(Collection<ReporteDetallado> reporteDetalladoCollection) {
        this.reporteDetalladoCollection = reporteDetalladoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Servicios)) {
            return false;
        }
        Servicios other = (Servicios) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Servicios[ id=" + id + " ]";
    }
    
}
