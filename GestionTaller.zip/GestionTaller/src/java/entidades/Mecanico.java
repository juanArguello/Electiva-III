/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "mecanico")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mecanico.findAll", query = "SELECT m FROM Mecanico m")
    , @NamedQuery(name = "Mecanico.findById", query = "SELECT m FROM Mecanico m WHERE m.id = :id")
    , @NamedQuery(name = "Mecanico.findByNombre", query = "SELECT m FROM Mecanico m WHERE m.nombre = :nombre")
    , @NamedQuery(name = "Mecanico.findByApellido", query = "SELECT m FROM Mecanico m WHERE m.apellido = :apellido")
    , @NamedQuery(name = "Mecanico.findByStatus", query = "SELECT m FROM Mecanico m WHERE m.status = :status")})
public class Mecanico implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "apellido")
    private String apellido;
    @Basic(optional = false)
    @Column(name = "status")
    private String status;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mecanico")
    private Collection<ReporteDetallado> reporteDetalladoCollection;

    public Mecanico() {
    }

    public Mecanico(Integer id) {
        this.id = id;
    }

    public Mecanico(Integer id, String status) {
        this.id = id;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @XmlTransient
    public Collection<ReporteDetallado> getReporteDetalladoCollection() {
        return reporteDetalladoCollection;
    }

    public void setReporteDetalladoCollection(Collection<ReporteDetallado> reporteDetalladoCollection) {
        this.reporteDetalladoCollection = reporteDetalladoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mecanico)) {
            return false;
        }
        Mecanico other = (Mecanico) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Mecanico[ id=" + id + " ]";
    }
    
}
