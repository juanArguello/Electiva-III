/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "reparacion_detallado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ReparacionDetallado.findAll", query = "SELECT r FROM ReparacionDetallado r")
    , @NamedQuery(name = "ReparacionDetallado.findByMatriculaVehiculos", query = "SELECT r FROM ReparacionDetallado r WHERE r.reparacionDetalladoPK.matriculaVehiculos = :matriculaVehiculos")
    , @NamedQuery(name = "ReparacionDetallado.findByIdServicios", query = "SELECT r FROM ReparacionDetallado r WHERE r.reparacionDetalladoPK.idServicios = :idServicios")
    , @NamedQuery(name = "ReparacionDetallado.findByTipoReparacion", query = "SELECT r FROM ReparacionDetallado r WHERE r.tipoReparacion = :tipoReparacion")})
public class ReparacionDetallado implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReparacionDetalladoPK reparacionDetalladoPK;
    @Basic(optional = false)
    @Column(name = "tipo_reparacion")
    private String tipoReparacion;
    @JoinColumn(name = "id_servicios", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Servicios servicios;
    @JoinColumn(name = "matricula_vehiculos", referencedColumnName = "matricula", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Vehiculos vehiculos;

    public ReparacionDetallado() {
    }

    public ReparacionDetallado(ReparacionDetalladoPK reparacionDetalladoPK) {
        this.reparacionDetalladoPK = reparacionDetalladoPK;
    }

    public ReparacionDetallado(ReparacionDetalladoPK reparacionDetalladoPK, String tipoReparacion) {
        this.reparacionDetalladoPK = reparacionDetalladoPK;
        this.tipoReparacion = tipoReparacion;
    }

    public ReparacionDetallado(String matriculaVehiculos, int idServicios) {
        this.reparacionDetalladoPK = new ReparacionDetalladoPK(matriculaVehiculos, idServicios);
    }

    public ReparacionDetalladoPK getReparacionDetalladoPK() {
        return reparacionDetalladoPK;
    }

    public void setReparacionDetalladoPK(ReparacionDetalladoPK reparacionDetalladoPK) {
        this.reparacionDetalladoPK = reparacionDetalladoPK;
    }

    public String getTipoReparacion() {
        return tipoReparacion;
    }

    public void setTipoReparacion(String tipoReparacion) {
        this.tipoReparacion = tipoReparacion;
    }

    public Servicios getServicios() {
        return servicios;
    }

    public void setServicios(Servicios servicios) {
        this.servicios = servicios;
    }

    public Vehiculos getVehiculos() {
        return vehiculos;
    }

    public void setVehiculos(Vehiculos vehiculos) {
        this.vehiculos = vehiculos;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reparacionDetalladoPK != null ? reparacionDetalladoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReparacionDetallado)) {
            return false;
        }
        ReparacionDetallado other = (ReparacionDetallado) object;
        if ((this.reparacionDetalladoPK == null && other.reparacionDetalladoPK != null) || (this.reparacionDetalladoPK != null && !this.reparacionDetalladoPK.equals(other.reparacionDetalladoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.ReparacionDetallado[ reparacionDetalladoPK=" + reparacionDetalladoPK + " ]";
    }
    
}
