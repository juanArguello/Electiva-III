/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "respuestos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Respuestos.findAll", query = "SELECT r FROM Respuestos r")
    , @NamedQuery(name = "Respuestos.findById", query = "SELECT r FROM Respuestos r WHERE r.id = :id")
    , @NamedQuery(name = "Respuestos.findByNombre", query = "SELECT r FROM Respuestos r WHERE r.nombre = :nombre")
    , @NamedQuery(name = "Respuestos.findByTipoServico", query = "SELECT r FROM Respuestos r WHERE r.tipoServico = :tipoServico")})
public class Respuestos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "tipo_servico")
    private String tipoServico;
    @OneToMany(mappedBy = "idRespuestos")
    private Collection<Servicios> serviciosCollection;
    @JoinColumn(name = "id_servicios", referencedColumnName = "id")
    @ManyToOne
    private Servicios idServicios;

    public Respuestos() {
    }

    public Respuestos(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(String tipoServico) {
        this.tipoServico = tipoServico;
    }

    @XmlTransient
    public Collection<Servicios> getServiciosCollection() {
        return serviciosCollection;
    }

    public void setServiciosCollection(Collection<Servicios> serviciosCollection) {
        this.serviciosCollection = serviciosCollection;
    }

    public Servicios getIdServicios() {
        return idServicios;
    }

    public void setIdServicios(Servicios idServicios) {
        this.idServicios = idServicios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Respuestos)) {
            return false;
        }
        Respuestos other = (Respuestos) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Respuestos[ id=" + id + " ]";
    }
    
}
